/* NetId(s): djg17, ret87. Time spent: hh hours, mm minutes. */

package gui;

import model.Board;
import model.Game;
import model.GameListener;
import model.Location;
import model.NotImplementedException;
import model.Player;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Scanner;

import javax.swing.*;

import clui.BoardPrinter;
import clui.ConsoleController;
import controller.Controller;
import controller.DumbAI;
import controller.RandomAI;
import controller.SmartAI;



public class Main extends JFrame{
	int first;// Stores the index(1..4) of the first player(Human,DumbAI,RandomAI,SmartAI) on the first combobox.
	//Index 0 asks the user to select a player.
	int second;// Stores the index(1..4) of the second player(Human,DumbAI,RandomAI,SmartAI) on the first combobox.
	//Index 0 asks the user to select a player.
	JButton start;// Begins the game with the two players selected from both comboboxes when selected.
	JButton quit;// Quits the game and exits the gui window when selected.
    JPanel center= new JPanel();// Displays the gameboard.
    JLabel gameState= new JLabel();// Displays the state of the game i.e. win, draw, or game still in play.
    JLabel rePrompt = new JLabel("Please select a player for both of the fields."); // Reprompts the user to select 
    //players when the option is at index 0, which asks the user to select a player.
    String[] controllers = {"Select your X player." ,"Human", "DumbAI", "RandomAI", "SmartAI"};//Stores all options to
    // be selected as the first player.
    String[] controllers1 = { "Select your O player.","Human", "DumbAI", "RandomAI", "SmartAI"};//Stores all options to
    // be selected as the first player.
    JComboBox <String> firstPlayerBox;// Displays all options that can be selected as the first player.
    JComboBox <String>secondPlayerBox;// Displays all options that can be selected as the second player.


	public Main()
	{
		super("Main");
		setTitle("Main Menu");
		this.start = new JButton("Start");
		this.quit = new JButton("Quit");



		add(this.start, BorderLayout.NORTH);
		add(this.quit, BorderLayout.SOUTH);
		start.addActionListener(new Listener());
		quit.addActionListener(new Listener());
		
	    
		this.firstPlayerBox=new JComboBox<String>(controllers);
		this.secondPlayerBox= new JComboBox<String>(controllers1);

		add(this.firstPlayerBox, BorderLayout.WEST);
		add(this.secondPlayerBox, BorderLayout.EAST);


		firstPlayerBox.addActionListener(new Listener());
		secondPlayerBox.addActionListener(new Listener());
		add(rePrompt,BorderLayout.CENTER);
		rePrompt.setHorizontalAlignment(0);
		rePrompt.setForeground(Color.RED);
		rePrompt.setVisible(false);
		


		start.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent arg0){
				rePrompt.setVisible(false);
				first= firstPlayerBox.getSelectedIndex();
				second = secondPlayerBox.getSelectedIndex();
				if(first!=0 && second!=0){
					remove(firstPlayerBox);
					remove(secondPlayerBox);
					remove(start);

					Game tic = new Game();
					//tic.addListener(new BoardPrinter());
					center.setLayout(new GridLayout(9,9));
					for (int i = 0; i < 9; i++){
					for (int j = 0; j < 9; j++){
							Square s= new Square(i,j,tic);
							center.add(s);
							tic.addListener(s);
						

						}
					}
					add(center, BorderLayout.CENTER);
					gameState.setHorizontalAlignment(0);
					add(gameState, BorderLayout.NORTH);
	
					if(first!=1){
						Controller playerX= createController(Player.X,first);
						tic.addListener(playerX);
					}
					if(second!=1){
						Controller playerO = createController(Player.O,second);
						tic.addListener(playerO);
					}
	
					pack();
				}
				else{

					rePrompt.setVisible(true);
				}
			}
		});
		
		quit.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{	
				dispose();
			}
		});

		
		pack();
	}
	private class Listener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			
			
		}
	}
	
	public static Controller createController(Player p, int playerNumber) {
		
		while(true) {

			switch(playerNumber) {
			case 2:
				return new DumbAI(p);
			case 3:
				return new RandomAI(p);
			case 4:
				return new SmartAI(p);				
			}
		}
	}
	
	
	


		public class Square extends JPanel implements MouseListener, GameListener{
			private final int r, c;
			private Game tic;
			private boolean humanPaintX = false;
			private boolean humanPaintO = false;
			private boolean painted;

			
			public Square(int r, int c,Game tic) {
				this.r = r; this.c = c; this.tic=tic;
				setPreferredSize(new Dimension(50,50));
				addMouseListener(this);
				painted =false;
			}
			public void ToggleX(){
				//boolean noWinner=tic.getBoard().getState()!=model.Board.State.HAS_WINNER;
				//boolean noDraw=tic.getBoard().getState()!=model.Board.State.DRAW;

				if(first==1){
					humanPaintX=true;
					repaint();
			        tic.submitMove(tic.nextTurn(),new Location(this.r,this.c));

				}
			}
			public void ToggleO(){
				//boolean noWinner=tic.getBoard().getState()!=model.Board.State.HAS_WINNER;
				//boolean noDraw=tic.getBoard().getState()!=model.Board.State.DRAW;
				if(second==1){
					humanPaintO=true;
					repaint();
			        tic.submitMove(tic.nextTurn(),new Location(this.r,this.c));

				}
			}

			public @Override void paint(Graphics g) {

				g.setColor(Color.WHITE);
				g.fillRect(0, 0, getWidth()-1, getHeight()-1);
				g.setColor(Color.BLACK);
				g.drawRect(0, 0, getWidth()-1, getHeight()-1);
				boolean validPosition=tic.getBoard().get(r,c)!=null;
		
				if (validPosition&&((tic.getBoard().get(r,c)==Player.X))||(humanPaintX && !painted)) {
					g.setColor(Color.BLACK);
					g.drawLine(5,5, getWidth()-5, getHeight()-5);
					g.drawLine(getWidth()-5, 5,5,getHeight()-5);
					humanPaintX=false;
					painted=true;


				}
				else if(validPosition&&((tic.getBoard().get(r,c)==Player.O))||(humanPaintO && !painted)){

					g.setColor(Color.BLACK);
					g.drawOval(0, 0, getWidth()-5, getHeight()-5);
					humanPaintO=false;
					painted=true;


				}
				
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				if(tic.nextTurn().equals(Player.X)){
					ToggleX();
				}
				else{
					ToggleO();
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseReleased(MouseEvent e) {
			}
		     @Override public void gameChanged(Game g) {
		    	 
				 switch(g.getBoard().getState()) {
						case HAS_WINNER:
						    gameState.setText(g.getBoard().getWinner().winner + " wins!");
							break;
						case DRAW:
							gameState.setText("Game ended in a draw!");
							break;
						case NOT_OVER:
							gameState.setText("It is " + g.nextTurn() + "'s turn");
							paintImmediately(0,0,getWidth(), getHeight());
							break;

			     }



		     }

		}



		public static void main(String[] args) {
			Main x= new Main();
			x.setVisible(true);
		}



}


